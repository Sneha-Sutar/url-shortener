const express = require('express');
const { Pool } = require('pg');
const crypto = require('crypto');
const app = express();
app.use(express.json());
app.use(express.static('public'));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

app.post('/api/shorten', async (req,res)=>{
  const { url } = req.body;
  const code = crypto.randomBytes(3).toString('hex');
  await pool.query('INSERT INTO links(code, url) VALUES($1,$2)',[code,url]);
  res.json({ code });
});

app.get('/:code', async (req,res)=>{
  const { code } = req.params;
  const result = await pool.query('SELECT url FROM links WHERE code=$1',[code]);
  if(result.rowCount===0) return res.status(404).send('Not found');
  res.redirect(result.rows[0].url);
});

app.listen(3000, ()=> console.log('Running on 3000'));
